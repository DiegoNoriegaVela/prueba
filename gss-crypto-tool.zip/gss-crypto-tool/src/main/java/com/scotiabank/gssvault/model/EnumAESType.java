package com.scotiabank.gssvault.model;

public enum EnumAESType {
    CBC, GCM, ECB, INVALID_AES_TYPE
}