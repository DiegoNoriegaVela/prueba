package com.scotiabank.gssvault.model;

public enum EnumInputType {
    TEXT, FILE, INVALID_INPUT_TYPE
}
