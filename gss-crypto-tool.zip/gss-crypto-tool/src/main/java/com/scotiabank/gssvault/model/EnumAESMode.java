package com.scotiabank.gssvault.model;

public enum EnumAESMode {
    ENCRYPT, DECRYPT, INVALID_AES_MODE
}
