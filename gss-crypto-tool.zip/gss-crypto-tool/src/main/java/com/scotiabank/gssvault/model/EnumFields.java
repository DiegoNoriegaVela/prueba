package com.scotiabank.gssvault.model;

public enum EnumFields {
    USERNAME, PASSWORD, INVALID_ENUM_VALUE
}
